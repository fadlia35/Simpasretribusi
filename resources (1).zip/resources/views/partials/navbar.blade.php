<div class="nav-header">
            <div class="brand-logo">
                <a href="index.html">
                    {{-- <b class="logo-abbr"><img src="{{ asset ('../theme/images/logo.png') }}" alt=""> </b> --}}
                    {{-- <span class="logo-compact"><img src="{{ asset ('../theme/images/logo-compact.png') }}" alt=""></span> --}}
                    <span class="brand-title">
                        {{-- <img src="{{ asset ('../theme/images/logo-text.png') }}" alt=""> --}}
                        <h3 style="color: white">SIMPAS</h3>
                    </span>
                </a>
            </div>
        </div>