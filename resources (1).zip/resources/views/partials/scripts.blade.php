    <script src="{{ asset ('../theme/plugins/common/common.min.js') }}"></script>
    <script src="{{ asset ('../theme/js/custom.min.js') }}"></script>
    <script src="{{ asset ('../theme/js/settings.js') }}"></script>
    <script src="{{ asset ('../theme/js/gleek.js') }}"></script>
    <script src="{{ asset ('../theme/js/styleSwitcher.js') }}"></script>

    <!-- Chartjs -->
    <script src="{{ asset ('../theme/plugins/chart.js/Chart.bundle.min.js') }}"></script>
    <!-- Circle progress -->
    <script src="{{ asset ('../theme/plugins/circle-progress/circle-progress.min.js') }}"></script>
    <!-- Datamap -->
    <script src="{{ asset ('../theme/plugins/d3v3/index.js') }}"></script>
    <script src="{{ asset ('../theme/plugins/topojson/topojson.min.js') }}"></script>
    <script src="{{ asset ('../theme/plugins/datamaps/datamaps.world.min.js') }}"></script>
    <!-- Morrisjs -->
    <script src="{{ asset ('../theme/plugins/raphael/raphael.min.js') }}"></script>
    <script src="{{ asset ('../theme/plugins/morris/morris.min.js') }}"></script>
    <!-- Pignose Calender -->
    <script src="{{ asset ('../theme/plugins/moment/moment.min.js') }}"></script>
    <script src="{{ asset ('../theme/plugins/pg-calendar/js/pignose.calendar.min.js') }}"></script>
    <!-- ChartistJS -->
    <script src="{{ asset ('../theme/plugins/chartist/js/chartist.min.js') }}"></script>
    <script src="{{ asset ('../theme/plugins/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js') }}"></script>

    <script src="{{ asset('../theme/plugins/toastr/js/toastr.min.js') }}"></script>


    <script src="{{ asset('theme/plugins/tables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('theme/plugins/tables/js/datatable/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('theme/plugins/tables/js/datatable-init/datatable-basic.min.js') }}"></script>

    <script src="{{ asset ('../theme/js/dashboard/dashboard-1.js') }}"></script>

    @stack('addScript')